<div class="jumbotron text-center" style="margin-bottom:0">
  <p>@copyright YoungJin University since 2018</p>
</div>