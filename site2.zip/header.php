<div class="jumbotron text-center" style="margin-bottom:0">
  <h1>SCPark's Home Page!</h1>
  <p>박성철의 홈페이지 방문을 환영합니다.</p> 
</div>
