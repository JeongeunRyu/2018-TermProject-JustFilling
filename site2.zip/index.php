<!DOCTYPE html>
<html>
<head>
	<?php require_once("html_head.php"); ?>
</head>
<body>
	<?php require_once("header.php"); ?>
	<?php require_once("menu.php"); ?>
	안녕하세요...
	<?php require_once("footer.php"); ?>
</body>
</html>